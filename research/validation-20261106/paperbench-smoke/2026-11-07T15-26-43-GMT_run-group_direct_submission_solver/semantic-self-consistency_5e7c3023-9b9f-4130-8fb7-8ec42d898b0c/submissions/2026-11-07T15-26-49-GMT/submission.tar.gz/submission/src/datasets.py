import json
from pathlib import Path


def load_sample(path: str = 'data/sample.json') -> dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))
