from collections import Counter
import hashlib
import math


def parse_answer(text):
    _, marker, answer = text.partition("The answer is")
    if not marker:
        return None
    answer = answer.strip().removesuffix(".").strip()
    if answer.startswith("(") and answer.endswith(")"):
        answer = answer[1:-1].strip()
    return answer


def modal_answer(answers):
    from collections import Counter

    counts = Counter(answer for answer in answers if answer is not None)
    return counts.most_common(1)[0][0] if counts else None


def _hash_embed(text):
    import hashlib

    digest = hashlib.sha512(text.encode('utf-8')).digest()
    values = [byte - 127.5 for byte in digest]
    norm = sum(value * value for value in values) ** 0.5
    return [value / norm for value in values]


def _l2(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def _cos(a, b):
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)


def cpw_answer(responses):
    parsed = [parse_answer(r) for r in responses]
    vectors = [_hash_embed(r) for r in responses]
    if not vectors:
        return None
    dim = len(vectors[0])
    centroid = [sum(v[i] for v in vectors) / len(vectors) for i in range(dim)]
    distances = [_l2(v, centroid) for v in vectors]
    total = sum(distances)
    if total == 0:
        return modal_answer(parsed)
    weights = [1.0 / (d / total if d else 1e-9) for d in distances]
    scores = {}
    for answer, weight in zip(parsed, weights):
        if answer is not None:
            scores[answer] = scores.get(answer, 0.0) + weight
    return max(scores, key=lambda k: (scores[k], k)) if scores else None


def scw_answer(responses):
    parsed = [parse_answer(r) for r in responses]
    vectors = [_hash_embed(r) for r in responses]
    scores = {}
    for vector, answer in zip(vectors, parsed):
        if answer is not None:
            scores[answer] = scores.get(answer, 0.0) + sum(_cos(vector, other) for other in vectors)
    return max(scores, key=lambda k: (scores[k], k)) if scores else None


def run(data: dict) -> dict:
    datasets = data.get("datasets", {})
    answers = datasets.get("answers", [])
    responses = datasets.get("responses", [])
    return {
        "chosen": modal_answer(answers),
        "parsed": [parse_answer(response) for response in responses],
        "cpw": cpw_answer(responses),
        "scw": scw_answer(responses),
    }