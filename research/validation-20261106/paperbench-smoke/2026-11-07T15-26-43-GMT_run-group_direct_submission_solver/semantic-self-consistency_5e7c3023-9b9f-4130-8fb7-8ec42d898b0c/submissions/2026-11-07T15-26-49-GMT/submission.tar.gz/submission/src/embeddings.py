from .core import _hash_embed


def embed_text(text: str) -> list[float]:
    return _hash_embed(text)
