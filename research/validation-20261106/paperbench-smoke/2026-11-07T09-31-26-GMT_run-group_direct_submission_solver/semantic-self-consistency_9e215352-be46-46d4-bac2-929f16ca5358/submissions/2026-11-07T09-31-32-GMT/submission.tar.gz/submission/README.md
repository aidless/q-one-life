minimal smoke submission
