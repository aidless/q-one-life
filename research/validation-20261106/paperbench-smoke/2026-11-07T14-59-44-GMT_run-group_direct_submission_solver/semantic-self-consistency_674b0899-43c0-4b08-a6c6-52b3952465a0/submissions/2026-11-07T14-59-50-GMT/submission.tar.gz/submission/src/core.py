"""Answer extraction and deterministic self-consistency voting.

This is a small, offline voting baseline, not the full paper experiment.
CPW uses supplied confidence weights; SCW uses supplied semantic-consistency
weights. Plain strings receive weight 1. Response mappings accept ``answer``
or ``text`` plus ``confidence`` (CPW) or ``consistency`` (SCW). No model is
called to estimate these scores. Ties are resolved by first appearance.
"""
import math
import re
from collections import Counter
from decimal import Decimal, InvalidOperation


_NUMBER = re.compile(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?')


def parse_answer(text):
    """Extract an explicit final answer, or normalize a supplied answer.

    Recognizes simple LaTeX boxed answers and 'answer is:'/'answer:' markers.
    Numeric answers are normalized so that, for example, '1.0' votes for '1'.
    Empty and non-string inputs return None. Unmarked prose is retained as
    an answer rather than guessing which number in a rationale was intended.
    """
    if not isinstance(text, str) or not text.strip():
        return None
    text = text.strip()
    boxed = re.findall(r'\\boxed\{([^{}]*)\}', text)
    if boxed:
        text = boxed[-1].strip()
    else:
        markers = list(re.finditer(
            r'\b(?:final\s+)?answer\s*(?:is\s*:?|:)\s*',
            text, flags=re.IGNORECASE))
        if markers:
            tail = text[markers[-1].end():].strip()
            text = tail.splitlines()[0].strip() if tail else ''
    text = text.strip().rstrip('.!?').strip()
    if not text:
        return None
    if _NUMBER.fullmatch(text):
        try:
            number = Decimal(text)
            if number == 0:
                return '0'
            # Normalize exactly without rounding through a float or the
            # Decimal context, and avoid expanding enormous exponents.
            sign, digits, exponent = number.as_tuple()
            digits = list(digits)
            while len(digits) > 1 and digits[-1] == 0:
                digits.pop()
                exponent += 1
            coefficient = ''.join(map(str, digits))
            prefix = '-' if sign else ''
            point = len(coefficient) + exponent
            if -20 <= point <= 20:
                if point <= 0:
                    value = '0.' + '0' * (-point) + coefficient
                elif point >= len(coefficient):
                    value = coefficient + '0' * (point - len(coefficient))
                else:
                    value = coefficient[:point] + '.' + coefficient[point:]
                return prefix + value
            return prefix + coefficient[0] + (
                '.' + coefficient[1:] if len(coefficient) > 1 else ''
            ) + 'e' + str(point - 1)
        except (InvalidOperation, ValueError, OverflowError):
            return text
    return text


def modal_answer(answers):
    """Return the most frequent parsed answer, ignoring missing answers."""
    counts = Counter()
    for answer in answers:
        parsed = parse_answer(answer)
        if parsed is not None:
            counts[parsed] += 1
    return max(counts, key=counts.get) if counts else None


def _weighted_answer(responses, weight_key):
    totals = {}
    for response in responses:
        if isinstance(response, dict):
            answer = response.get('answer')
            if answer is None:
                answer = response.get('text')
            weight = response.get(weight_key, 1.0)
        else:
            answer, weight = response, 1.0
        parsed = parse_answer(answer)
        if parsed is None or isinstance(weight, bool):
            continue
        try:
            weight = float(weight)
        except (TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(weight) or weight <= 0:
            continue
        # Decimal keeps sums of individually finite weights from overflowing.
        totals[parsed] = totals.get(parsed, Decimal(0)) + Decimal(str(weight))
    return max(totals, key=totals.get) if totals else None


def cpw_answer(responses):
    """Choose the answer with the largest total supplied confidence."""
    return _weighted_answer(responses, 'confidence')


def scw_answer(responses):
    """Choose the answer with the largest supplied consistency total."""
    return _weighted_answer(responses, 'consistency')


def run(data: dict) -> dict:
    """Apply modal voting to data['datasets']['answers']."""
    return {'chosen': modal_answer(data['datasets']['answers'])}
