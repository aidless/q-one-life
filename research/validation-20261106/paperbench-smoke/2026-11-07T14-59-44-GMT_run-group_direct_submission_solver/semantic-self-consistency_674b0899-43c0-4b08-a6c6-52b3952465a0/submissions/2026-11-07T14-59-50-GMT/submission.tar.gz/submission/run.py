"""Read one JSON input object from stdin and write one JSON result."""
import json
import sys

from src.core import run


if __name__ == '__main__':
    json.dump(run(json.load(sys.stdin)), sys.stdout)
    sys.stdout.write('\n')
