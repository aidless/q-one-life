import unittest

from src.core import cpw_answer, modal_answer, parse_answer, run, scw_answer


class ProjectTests(unittest.TestCase):
    def test_parse_answer(self):
        self.assertEqual(parse_answer('Reasoning. Final answer: 42.'), '42')
        self.assertEqual(parse_answer(r'Therefore \boxed{1.00}'), '1')
        self.assertEqual(parse_answer('-0.0'), '0')
        self.assertEqual(parse_answer('blue'), 'blue')
        self.assertIsNone(parse_answer('  '))
        self.assertIsNone(parse_answer(None))

    def test_modal_and_run(self):
        self.assertEqual(run({'datasets': {'answers': ['1', '1', '2']}}),
                         {'chosen': '1'})
        self.assertEqual(modal_answer(['2', '1']), '2')
        self.assertEqual(modal_answer(['1.0', '2', '1']), '1')
        self.assertIsNone(modal_answer([None, '']))
        self.assertIsNone(modal_answer([]))

    def test_weighted_answers(self):
        responses = [
            {'answer': '1', 'confidence': 0.2, 'consistency': 0.8},
            {'text': 'Final answer: 1', 'confidence': 0.2, 'consistency': 0.8},
            {'answer': '2', 'confidence': 0.9, 'consistency': 0.1},
        ]
        self.assertEqual(cpw_answer(responses), '2')
        self.assertEqual(scw_answer(responses), '1')
        self.assertEqual(cpw_answer(['1', '1', '2']), '1')
        self.assertEqual(scw_answer(['2', '1']), '2')
        self.assertIsNone(cpw_answer([{'answer': '1', 'confidence': -1}]))
        self.assertIsNone(scw_answer([{'answer': '1', 'consistency': 'nan'}]))
        self.assertIsNone(cpw_answer([]))
        self.assertIsNone(scw_answer([]))


if __name__ == '__main__':
    unittest.main()
