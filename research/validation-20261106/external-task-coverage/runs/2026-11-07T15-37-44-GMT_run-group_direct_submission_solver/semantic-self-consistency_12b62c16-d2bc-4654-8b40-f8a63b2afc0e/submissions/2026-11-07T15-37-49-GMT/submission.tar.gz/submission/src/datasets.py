import json
from pathlib import Path


def load_sample(path="data/sample.json"):
    return json.loads(Path(path).read_text(encoding="utf-8"))
