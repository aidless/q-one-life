def parse_answer(text):
    marker = "The answer is"
    if marker not in text:
        return None
    answer = text.split(marker, 1)[1].strip()
    if answer.endswith("."):
        answer = answer[:-1].strip()
    if answer.startswith("(") and answer.endswith(")"):
        answer = answer[1:-1].strip()
    return answer

from collections import Counter


def modal_answer(answers):
    counts = Counter(answer for answer in answers if answer is not None)
    return counts.most_common(1)[0][0] if counts else None

import hashlib


def _hash_embed(text):
    """Return a deterministic 64-dimensional unit vector for a string."""
    digest = hashlib.sha512(text.encode("utf-8")).digest()
    values = [byte - 127.5 for byte in digest]
    norm = sum(value * value for value in values) ** 0.5
    return [value / norm for value in values]

import math


def cpw_answer(responses):
    """Return the parsed answer closest to the embedding centroid, or None."""
    def _l2(a, b):
        return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

    answers = []
    embeddings = []
    for response in responses:
        answer = parse_answer(response)
        if answer is not None:
            answers.append(answer)
            embeddings.append(list(_hash_embed(str(answer))))

    if not answers:
        return None

    count = len(embeddings)
    centroid = [sum(values) / count for values in zip(*embeddings)]
    weights = [1.0 / (_l2(embedding, centroid) + 1e-12)
               for embedding in embeddings]
    best_index = max(range(len(answers)), key=weights.__getitem__)
    return answers[best_index]

import math


def scw_answer(responses):
    answers = [parse_answer(response) for response in responses]
    answers = [answer for answer in answers if answer is not None]
    if not answers:
        return None

    embeddings = [_hash_embed(str(answer)) for answer in answers]
    norms = [math.sqrt(sum(x * x for x in vector)) for vector in embeddings]

    def total_similarity(i):
        total = 0.0
        for j, vector in enumerate(embeddings):
            if i == j or norms[i] == 0 or norms[j] == 0:
                continue
            dot = sum(x * y for x, y in zip(embeddings[i], vector))
            total += dot / (norms[i] * norms[j])
        return total

    best_index = max(range(len(answers)), key=total_similarity)
    return answers[best_index]

def run(data: dict) -> dict:
    answers = data["datasets"]["answers"]
    responses = data["datasets"].get("responses", [])
    return {
        "chosen": modal_answer(answers),
        "parsed": [parse_answer(r) for r in responses],
        "cpw": cpw_answer(responses),
        "scw": scw_answer(responses),
    }
