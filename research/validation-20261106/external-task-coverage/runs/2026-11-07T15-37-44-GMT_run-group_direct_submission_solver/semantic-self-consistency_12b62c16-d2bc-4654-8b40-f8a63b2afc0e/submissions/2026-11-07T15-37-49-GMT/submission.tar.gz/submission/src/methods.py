from .core import cpw_answer, scw_answer
