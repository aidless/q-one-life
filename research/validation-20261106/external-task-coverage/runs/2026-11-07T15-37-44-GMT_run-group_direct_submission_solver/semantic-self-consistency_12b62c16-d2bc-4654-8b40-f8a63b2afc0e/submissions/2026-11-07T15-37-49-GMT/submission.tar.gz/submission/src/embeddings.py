from .core import _hash_embed


def embed_text(text):
    return _hash_embed(text)
