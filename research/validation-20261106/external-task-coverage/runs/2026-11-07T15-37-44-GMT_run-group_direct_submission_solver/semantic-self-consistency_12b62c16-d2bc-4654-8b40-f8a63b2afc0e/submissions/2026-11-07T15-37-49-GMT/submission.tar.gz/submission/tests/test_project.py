from src.core import parse_answer, modal_answer, cpw_answer, scw_answer, run, _hash_embed


def test_parse_answer():
    assert parse_answer("Reasoning. The answer is (19).") == "19"


def test_parse_answer_missing():
    assert parse_answer("none") is None


def test_modal_answer():
    assert modal_answer(["1", "1", "2", None]) == "1"


def test_hash_embed_unit():
    vector = _hash_embed("hello")
    assert len(vector) == 64
    assert abs(sum(x * x for x in vector) - 1.0) < 1e-9


def test_cpw_and_scw():
    responses = ["The answer is 1", "The answer is 1", "The answer is 2"]
    assert cpw_answer(responses) in ("1", "2")
    assert scw_answer(responses) in ("1", "2")


def test_run():
    result = run({"datasets": {"answers": ["1", "1", "2"], "responses": ["The answer is 1"]}})
    assert result["chosen"] == "1"
    assert result["parsed"] == ["1"]
