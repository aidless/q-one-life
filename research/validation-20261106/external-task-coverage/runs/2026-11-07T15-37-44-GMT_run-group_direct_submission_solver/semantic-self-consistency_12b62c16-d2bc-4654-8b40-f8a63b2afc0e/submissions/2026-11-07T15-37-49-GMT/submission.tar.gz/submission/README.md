# Model-core PaperBench package

All six research-logic fragments in src/core.py were produced by short model calls. Host templates provide the entrypoint, tests, data and packaging metadata. No real PaperBench score is claimed.
